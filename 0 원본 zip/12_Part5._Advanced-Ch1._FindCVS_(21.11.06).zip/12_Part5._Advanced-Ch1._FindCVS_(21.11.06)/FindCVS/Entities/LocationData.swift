//
//  LocationData.swift
//  FindCVS
//
//  Created by Bo-Young PARK on 2021/09/26.
//

import Foundation

struct LocationData: Decodable {
    let documents: [KLDocument]
}
