// AppDelegate
// 22, 23번째 줄 삭제할 부분        
//        GIDSignIn.sharedInstance.clientID = FirebaseApp.app()?.options.clientID
//        GIDSignIn.sharedInstance.delegate = self

// 93번째 줄 이하 삭제할 부분
//extension AppDelegate: GIDSignInDelegate {
//    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error?) {
//        // ...
//        if let error = error {
//            print ("Error Google sign in: %@", error)
//            return
//        }
//
//        guard let authentication = user.authentication else { return }
//        let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken, accessToken: authentication.accessToken)
//        Auth.auth().signIn(with: credential) {[weak self] _, _ in
//            self?.showMainViewController()
//        }
//    }
//
//    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!, withError error: Error!) {
//        // Perform any operations when the user disconnects from app here.
//        // ...
//    }
//}

//extension AppDelegate {
//    ///Main 화면으로 보내기
//    func showMainViewController() {
//        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
//        let mainViewController = storyboard.instantiateViewController(identifier: "MainViewController")
//        mainViewController.modalPresentationStyle = .fullScreen
//        UIApplication.shared.windows.first?.rootViewController?.show(mainViewController, sender: nil)
//    }
//}

