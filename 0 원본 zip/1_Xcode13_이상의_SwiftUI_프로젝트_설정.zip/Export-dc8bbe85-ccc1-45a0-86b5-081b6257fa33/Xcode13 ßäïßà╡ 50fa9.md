# Xcode13 이상의 SwiftUI 프로젝트 설정

> AppDelegate, SceneDelegate를 수동으로 설정하기
> 

## AppDelegate 생성하기

- Cmd+N 로 새 Swift 파일을 추가합니다. 파일명은 **AppDelegate.swift** 로 설정합니다.
    
    ![스크린샷 2022-02-08 21.48.16.png](Xcode13%20%E1%84%8B%E1%85%B5%2050fa9/%EC%8A%A4%ED%81%AC%EB%A6%B0%EC%83%B7_2022-02-08_21.48.16.png)
    
- 다음과 같이 코드를 입력하여 AppDelegate class를 생성합니다.
    
    ```swift
    import Foundation
    import UIKit
    
    class AppDelegate: NSObject, UIApplicationDelegate {
        func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
            return true
        }
    }
    ```
    
    - 코드상 추가한 `func` 외에도 `AppDelegate` 클래스 내에서 필요한 함수를 추가하여 기존의 자동 생성된 `AppDelegate` 와 같은 용도로 사용할 수 있습니다.
- Project명+App.swift 파일로 이동하여 다음 코드를 추가합니다.
    
    ```swift
    @main
    struct ProjectApp: App {
    		//👇이 부분을 추가합니다.
        @UIApplicationDelegateAdaptor var appDelegate: AppDelegate
        
        var body: some Scene {
            WindowGroup {
                ContentView()
            }
        }
    }
    ```
    

## SceneDelegate 생성하기

- Cmd+N 로 새 Swift 파일을 추가합니다. 파일명은 **SceneDelegate.swift** 로 설정합니다.
- 다음과 같이 코드를 입력하여 SceneDelegate class를 생성합니다.
    
    ```swift
    import Foundation
    import UIKit
    
    class SceneDelegate: NSObject, UIWindowSceneDelegate {
        func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
            //...
        }
    }
    ```
    
- **AppDelegate.swift** 파일로 이동하여 다음 코드를 추가합니다.
    
    ```swift
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
            let sceneConfig = UISceneConfiguration(name: nil, sessionRole: connectingSceneSession.role)
            sceneConfig.delegateClass = SceneDelegate.self
            return sceneConfig
        }
    ```